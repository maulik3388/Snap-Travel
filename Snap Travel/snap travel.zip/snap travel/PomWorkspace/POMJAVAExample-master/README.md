# POMJAVAExample
Basic POM Example
Article Link: https://www.swtestacademy.com/page-object-model-java/

For generics, go here: https://www.swtestacademy.com/page-object-model-java-generics/
